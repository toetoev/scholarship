<!DOCTYPE html>
<html>
<head>
	<title>Send Email</title>
</head>
<body>
	
	<?php $__currentLoopData = $e_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<h3><?php echo e($data->description); ?></h3>
	<h4><?php echo e($data->mname); ?></h4>
	<h4><?php echo e($data->uname); ?></h4>
	<h4><?php echo e($data->cname); ?></h4>
	<p>My name is <?php echo e($data->name); ?>.I'm <?php echo e($data->grade); ?>.I'm attaching a copy of <a href="<?php echo e(asset($data->attachment)); ?>" download="download">Attachment File</a></p>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\scholarship\resources\views/frontend/sendmail.blade.php ENDPATH**/ ?>