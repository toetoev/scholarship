<?php $__env->startSection('content'); ?>
<div class="main-content">
	<div class="section__content section__content--p30">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-6">
					<div class="card">
						<div class="card-header">Country</div>
						<div class="card-body">
							<form action="<?php echo e(route('country.store')); ?>" method="post" novalidate="novalidate">
								<?php echo csrf_field(); ?>
								<div class="form-group has-success">
									<label for="country" class="control-label mb-1">Country Name</label>
									<input id="country" name="country" type="text" class="form-control cc-name valid" data-val="true" data-val-required="Please enter the name on card"
									aria-required="true" aria-invalid="false" aria-describedby="cc-name-error">
									<span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>

									<?php if($errors->has('country')): ?>
									<i class="zmdi zmdi-alert-octagon"></i>
									<span class="text-danger"><?php echo e($errors->first('country')); ?></span>
									<?php endif; ?>

								</div>

								<div class="form-group has-success">
									<label for="region" class="control-label mb-1">Select Region</label>
									
									<div class="form-group">
										<?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="custom-control custom-checkbox custom-control-inline">
												<input class="custom-control-input" type="checkbox" id="<?php echo e($region->id); ?>" name="regions[]" value="<?php echo e($region->id); ?>">

												<label for="<?php echo e($region->id); ?>" class="custom-control-label mb-1"><?php echo e($region->region); ?></label>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
									
									<?php if($errors->has('checkbox')): ?>
									<i class="zmdi zmdi-alert-octagon"></i>
									<span class="text-danger"><?php echo e($errors->first('checkbox')); ?></span>
									<?php endif; ?>
								</div>

								<div>
									<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
										<i class="fa fa-lock fa-lg"></i>&nbsp;
										<span id="payment-button-amount">Save</span>
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\scholarship\resources\views/country/create.blade.php ENDPATH**/ ?>