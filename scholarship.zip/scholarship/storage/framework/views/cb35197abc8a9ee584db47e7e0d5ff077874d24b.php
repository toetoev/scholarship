<?php $__env->startSection('content'); ?>
<div class="main-content">
	<div class="section__content section__content--p30">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-12">
					<div class="card">
						<div class="card-header">Scholarship Form</div>
						<div class="card-body">
							<form action="<?php echo e(route('scholar.update',$scholar->id)); ?>" method="post" novalidate="novalidate" enctype="multipart/form-data">
								<?php echo csrf_field(); ?>
								<?php echo method_field('PUT'); ?>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group has-success">
											<label for="description" class="control-label mb-1">Description</label>
											<textarea name="description" id="textarea-input" rows="4" class="form-control" ><?php echo e($scholar->description); ?></textarea>
										</div>
									</div>

									<div class="col-md-6">
										<div class="form-group has-success">
											<label for="eligibility" class="control-label mb-1">Eligibility</label>
											<textarea name="eligibility" id="textarea-input" rows="4" class="form-control"><?php echo e($scholar->eligibility); ?></textarea>
										</div>
									</div>

								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group has-success">
											<label for="inclusion" class="control-label mb-1">Scholarship Inclusion</label>
											
											<input id="inclusion" name="inclusion" type="text" class="form-control cc-name valid" data-val="true" data-val-required="Please enter the name on card"
											aria-required="true" aria-invalid="false" aria-describedby="cc-name-error" value="<?php echo e($scholar->inclusion); ?>">
											<span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group has-success">
											<label for="deadline" class="control-label mb-1">Dead Line</label>
											
											<input type="date" class="form-control" name="deadline" value="<?php echo e($scholar->deadline); ?>">
										</div>
									</div>
								</div>

								<div class="row">
										<div class="col-md-6">
										<label for="deadline" class="control-label">Course Duration</label>
										<div class="t-datepicker">
											
												<div class="t-check-in"></div>
												<div class="t-check-out"></div>
										</div>
										</div>
								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group has-success">
											<label for="logo" class="control-label mb-1">Logo</label>	
											<input type="file" name="logo" class="form-control-file">
											<input type="hidden" name="oldlogo" value="<?php echo e(asset($scholar->logo)); ?>">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group has-success">
											<label for="university" class="control-label mb-1">Select University</label>

											<select id="university" name="university" class="custom-select mr-sm-2">
												<?php $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $university): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($university->id); ?>" 
													<?php if ($scholar->university_id == $university->id): ?>
														selected
														<?php endif; ?>>
														<?php echo e($university->name); ?>

													</option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group has-success">
											<label for="major" class="control-label mb-1">Select Major</label>

											<select id="major" name="major" class="custom-select mr-sm-2">
												<?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($major->id); ?>" 
													<?php if ($scholar->major_id == $major->id): ?>
														selected
														<?php endif; ?>>
														<?php echo e($major->name); ?>

													</option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group has-success">
											<label for="grade" class="control-label mb-1">Select Grade</label>
											
											<select id="grade" name="grade" class="custom-select mr-sm-2">
												<?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($grade->id); ?>" 
													<?php if ($scholar->grade_id == $grade->id): ?>
														selected
														<?php endif; ?>>
														<?php echo e($grade->grade); ?>

													</option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
								</div>

								<div>
									<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
										<i class="fa fa-lock fa-lg"></i>&nbsp;
										<span id="payment-button-amount">Save</span>
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$("#startdate").change(function(){
			var startdate = $("#startdate").val();
			console.log(startdate);
			$("#date").val(startdate);
		})
		$("#enddate").change(function(){
			var enddate = $("#enddate").val();
			var date = $("#date").val();
			console.log(date,enddate);
			if(date<=enddate){
				alert("error") ;
			}
		})
	})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\scholarship\resources\views/scholarship/edit.blade.php ENDPATH**/ ?>